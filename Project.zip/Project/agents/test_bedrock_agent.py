#!/usr/bin/env python3
"""
Test AWS Bedrock Agent Connection with Enhanced Debugging
"""

import boto3
import json
import uuid
import logging
from botocore.exceptions import ClientError, NoCredentialsError
from datetime import datetime

# Set up detailed logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_aws_bedrock_agent():
    """Test AWS Bedrock Agent connection and inference with debugging"""
    print("🤖 Testing AWS Bedrock Agent Connection...")
    print("=" * 60)
    
    # AWS Configuration - Updated with Bedrock Agent ID
    AWS_ACCESS_KEY_ID = "AKIAQXOXUP2ZWNNMUFOL"
    AWS_SECRET_ACCESS_KEY = "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"
    AWS_REGION = "eu-north-1"
    BEDROCK_AGENT_ID = "FTQPCW1EV3"
    AGENT_ALIAS_ID = "TSTALIASID"  # Test alias from console
    
    try:
        # Test AWS credentials
        print("1. Testing AWS credentials...")
        session = boto3.Session(
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            region_name=AWS_REGION
        )
        
        # Test STS
        sts_client = session.client('sts')
        identity = sts_client.get_caller_identity()
        print(f"   ✅ AWS credentials valid")
        print(f"   📋 Account: {identity.get('Account', 'Unknown')}")
        print(f"   👤 User: {identity.get('Arn', 'Unknown')}")
        
    except Exception as e:
        print(f"   ❌ AWS credentials failed: {e}")
        return False
    
    try:
        # Test Bedrock Agent
        print("\n2. Testing Bedrock Agent access...")
        bedrock_agent_client = session.client('bedrock-agent-runtime')
        
        print(f"   🎯 Agent ID: {BEDROCK_AGENT_ID}")
        print(f"   🏷️  Alias ID: {AGENT_ALIAS_ID}")
        print(f"   🌍 Region: {AWS_REGION}")
        
        # Test prompt
        test_prompt = """
Please help me make a decision about creating an offer.

Context:
- Trigger type: arduino
- Suggested amount: 1000000 lovelace (1 ADA)
- Additional context: test transaction
- Source: test_script

Should I create this offer? Please respond with your decision and reasoning.
"""
        
        print("   🧪 Testing Bedrock Agent inference...")
        logger.debug(f"Sending prompt: {test_prompt}")
        
        session_id = str(uuid.uuid4())
        print(f"   🔑 Session ID: {session_id}")
        
        response = bedrock_agent_client.invoke_agent(
            agentId=BEDROCK_AGENT_ID,
            agentAliasId=AGENT_ALIAS_ID,
            sessionId=session_id,
            inputText=test_prompt
        )
        
        print(f"   📥 Response received: {type(response)}")
        logger.debug(f"Full response: {response}")
        
        # Extract response from event stream
        decision_text = ""
        event_count = 0
        
        print("   📡 Processing event stream...")
        
        if 'completion' in response:
            for event in response['completion']:
                event_count += 1
                logger.debug(f"Event {event_count}: {event}")
                
                if 'chunk' in event:
                    chunk = event['chunk']
                    print(f"   📦 Chunk received: {chunk.keys()}")
                    
                    if 'bytes' in chunk:
                        chunk_text = chunk['bytes'].decode('utf-8')
                        decision_text += chunk_text
                        print(f"   📝 Chunk text: {chunk_text}")
                    else:
                        print(f"   ⚠️  No bytes in chunk: {chunk}")
                        
                elif 'trace' in event:
                    trace = event['trace']
                    print(f"   🔍 Trace: {trace}")
                    
                else:
                    print(f"   ❓ Unknown event type: {event}")
        else:
            print(f"   ❌ No 'completion' in response: {response.keys()}")
            return False
        
        print(f"\n   📤 Full Agent Response ({len(decision_text)} chars):")
        print(f"   {'-' * 50}")
        print(f"   {decision_text}")
        print(f"   {'-' * 50}")
        
        # Try to parse as JSON
        try:
            json_start = decision_text.find('{')
            json_end = decision_text.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                json_text = decision_text[json_start:json_end]
                parsed = json.loads(json_text)
                print(f"   ✅ JSON parsed successfully: {parsed}")
            else:
                print(f"   ℹ️  No JSON structure found in response")
                print(f"   📊 Response analysis:")
                print(f"      - Length: {len(decision_text)} characters")
                print(f"      - Contains 'accept': {'accept' in decision_text.lower()}")
                print(f"      - Contains 'reject': {'reject' in decision_text.lower()}")
                print(f"      - Contains numbers: {any(c.isdigit() for c in decision_text)}")
            
            return True
            
        except json.JSONDecodeError as e:
            print(f"   ⚠️  JSON parsing failed: {e}")
            print(f"   📊 Text response analysis successful")
            return True
            
    except ClientError as e:
        print(f"   ❌ Bedrock Agent client error: {e}")
        error_code = e.response.get('Error', {}).get('Code', 'Unknown')
        error_message = e.response.get('Error', {}).get('Message', 'Unknown')
        print(f"   🔍 Error Code: {error_code}")
        print(f"   💬 Error Message: {error_message}")
        
        if error_code == 'ValidationException':
            print(f"   💡 Suggestion: Check Agent ID and Alias ID in AWS Console")
        elif error_code == 'AccessDeniedException':
            print(f"   💡 Suggestion: Check IAM permissions for Bedrock Agent")
        
        return False
    except Exception as e:
        print(f"   ❌ Unexpected error: {e}")
        logger.exception("Full error details:")
        return False

def test_agent_with_different_aliases():
    """Test with different possible alias IDs"""
    print("\n3. Testing different alias IDs...")
    
    AWS_ACCESS_KEY_ID = "AKIAQXOXUP2ZWNNMUFOL"
    AWS_SECRET_ACCESS_KEY = "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"
    AWS_REGION = "eu-north-1"
    BEDROCK_AGENT_ID = "FTQPCW1EV3"
    
    session = boto3.Session(
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        region_name=AWS_REGION
    )
    
    bedrock_agent_client = session.client('bedrock-agent-runtime')
    
    # Common alias IDs to try
    alias_ids = [
        "TSTALIASID",
        "TestAlias",
        "test",
        "default",
        "DRAFT",
        "latest"
    ]
    
    simple_prompt = "Hello, can you help me make a decision?"
    
    for alias_id in alias_ids:
        try:
            print(f"   🧪 Testing alias: {alias_id}")
            
            response = bedrock_agent_client.invoke_agent(
                agentId=BEDROCK_AGENT_ID,
                agentAliasId=alias_id,
                sessionId=str(uuid.uuid4()),
                inputText=simple_prompt
            )
            
            print(f"   ✅ Alias {alias_id} works!")
            return alias_id
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            print(f"   ❌ Alias {alias_id} failed: {error_code}")
            
        except Exception as e:
            print(f"   ❌ Alias {alias_id} error: {e}")
    
    return None

if __name__ == "__main__":
    print("🚀 Starting Enhanced Bedrock Agent Test")
    print("=" * 60)
    
    success = test_aws_bedrock_agent()
    
    if not success:
        print("\n🔧 Trying different alias IDs...")
        working_alias = test_agent_with_different_aliases()
        
        if working_alias:
            print(f"\n✅ Found working alias: {working_alias}")
            print(f"Update your config to use: agentAliasId='{working_alias}'")
        else:
            print("\n❌ No working alias found")
    
    if success:
        print("\n🎉 AWS Bedrock Agent setup successful!")
        print("✅ Agent A can now use real Bedrock Agent for decisions.")
        print(f"🔧 Use Agent ID: FTQPCW1EV3")
        print(f"🏷️  Use Alias ID: TSTALIASID")
    else:
        print("\n⚠️  AWS Bedrock Agent setup needs attention.")
        print("💡 Check the AWS Console for correct Agent ID and Alias ID.")
        print("🔄 Agent A will use mock mode as fallback.")
    
    print("\n" + "=" * 60)
