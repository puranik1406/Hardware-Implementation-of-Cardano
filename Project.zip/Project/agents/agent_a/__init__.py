"""
Agent A (Buyer Logic) Package
"""

__version__ = "1.0.0"
__author__ = "Imad"
__description__ = "AI agent for making and evaluating payment offers"

