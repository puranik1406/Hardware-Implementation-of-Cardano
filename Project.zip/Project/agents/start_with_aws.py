#!/usr/bin/env python3
"""
Start Agent A with AWS Bedrock Configuration
"""

import os
import sys
import uvicorn

def setup_aws_environment():
    """Set up AWS environment variables"""
    print("🔐 Setting up AWS Bedrock environment...")
    
    # Set AWS credentials
    os.environ["AWS_ACCESS_KEY_ID"] = "AKIAQXOXUP2ZWNNMUFOL"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "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"
    os.environ["AWS_REGION"] = "eu-north-1"
    
    # Set Agent A configuration
    os.environ["USE_MOCK_BEDROCK"] = "false"
    os.environ["BEDROCK_MODEL_ID"] = "anthropic.claude-3-sonnet-20240229-v1:0"
    os.environ["LOG_LEVEL"] = "INFO"
    os.environ["HOST"] = "0.0.0.0"
    os.environ["PORT"] = "8001"
    
    print("✅ Environment variables set:")
    print(f"   AWS_REGION: {os.environ['AWS_REGION']}")
    print(f"   USE_MOCK_BEDROCK: {os.environ['USE_MOCK_BEDROCK']}")
    print(f"   BEDROCK_MODEL_ID: {os.environ['BEDROCK_MODEL_ID']}")
    print(f"   LOG_LEVEL: {os.environ['LOG_LEVEL']}")

def test_aws_connection():
    """Test AWS connection before starting service"""
    try:
        import boto3
        session = boto3.Session(
            aws_access_key_id=os.environ["AWS_ACCESS_KEY_ID"],
            aws_secret_access_key=os.environ["AWS_SECRET_ACCESS_KEY"],
            region_name=os.environ["AWS_REGION"]
        )
        
        # Test credentials
        sts_client = session.client('sts')
        identity = sts_client.get_caller_identity()
        print(f"✅ AWS credentials valid (Account: {identity.get('Account', 'Unknown')})")
        return True
        
    except Exception as e:
        print(f"❌ AWS connection failed: {e}")
        print("Falling back to mock mode...")
        os.environ["USE_MOCK_BEDROCK"] = "true"
        return False

def main():
    """Start Agent A with AWS Bedrock"""
    print("🚀 Starting Agent A with AWS Bedrock...")
    print("=" * 50)
    
    # Set up environment
    setup_aws_environment()
    
    # Test AWS connection
    aws_working = test_aws_connection()
    
    if aws_working:
        print("🔐 Using real AWS Bedrock")
    else:
        print("🧪 Using mock Bedrock (AWS connection failed)")
    
    print("\n📡 Starting Agent A service...")
    print("Service will be available at: http://localhost:8001")
    print("API Documentation: http://localhost:8001/docs")
    print("\nPress Ctrl+C to stop the service")
    print("=" * 50)
    
    try:
        # Start the service
        uvicorn.run(
            "agent_a.main:app",
            host=os.environ.get("HOST", "0.0.0.0"),
            port=int(os.environ.get("PORT", "8001")),
            log_level=os.environ.get("LOG_LEVEL", "info").lower(),
            reload=False
        )
    except KeyboardInterrupt:
        print("\n🛑 Service stopped by user")
    except Exception as e:
        print(f"❌ Failed to start service: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
