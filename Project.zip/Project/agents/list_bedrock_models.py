#!/usr/bin/env python3
"""
List available Bedrock models in eu-north-1 region
"""

import boto3
import json

def list_bedrock_models():
    """List available Bedrock models"""
    print("🔍 Listing available Bedrock models in eu-north-1...")
    
    try:
        # Create Bedrock client
        bedrock_client = boto3.client(
            'bedrock',
            aws_access_key_id="AKIAQXOXUP2ZWNNMUFOL",
            aws_secret_access_key="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",
            region_name="eu-north-1"
        )
        
        # List foundation models
        response = bedrock_client.list_foundation_models()
        models = response.get('modelSummaries', [])
        
        print(f"Found {len(models)} models:")
        print("=" * 50)
        
        for model in models:
            model_id = model.get('modelId', 'Unknown')
            model_name = model.get('modelName', 'Unknown')
            provider = model.get('providerName', 'Unknown')
            
            print(f"📋 Model ID: {model_id}")
            print(f"   Name: {model_name}")
            print(f"   Provider: {provider}")
            print()
        
        # Try to find Claude models
        claude_models = [m for m in models if 'claude' in m.get('modelId', '').lower()]
        
        if claude_models:
            print("🤖 Claude models found:")
            for model in claude_models:
                print(f"   ✅ {model.get('modelId', 'Unknown')}")
        else:
            print("❌ No Claude models found in this region")
            
    except Exception as e:
        print(f"❌ Error listing models: {e}")

if __name__ == "__main__":
    list_bedrock_models()
