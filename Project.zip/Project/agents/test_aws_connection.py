#!/usr/bin/env python3
"""
Test AWS Bedrock Connection
"""

import boto3
import json
from botocore.exceptions import ClientError, NoCredentialsError

def test_aws_bedrock():
    """Test AWS Bedrock connection and inference"""
    print("🔐 Testing AWS Bedrock Connection...")
    print("=" * 50)
    
    # AWS Configuration - Updated with new Bedrock ID
    AWS_ACCESS_KEY_ID = "AKIAQXOXUP2ZWNNMUFOL"
    AWS_SECRET_ACCESS_KEY = "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"
    AWS_REGION = "eu-north-1"
    BEDROCK_MODEL_ID = "FTQPCW1EV3"
    
    try:
        # Test AWS credentials
        print("1. Testing AWS credentials...")
        session = boto3.Session(
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
            region_name=AWS_REGION
        )
        
        # Test STS
        sts_client = session.client('sts')
        identity = sts_client.get_caller_identity()
        print(f"   ✅ AWS credentials valid")
        print(f"   📋 Account: {identity.get('Account', 'Unknown')}")
        
    except Exception as e:
        print(f"   ❌ AWS credentials failed: {e}")
        return False
    
    try:
        # Test Bedrock
        print("\n2. Testing Bedrock access...")
        bedrock_client = session.client('bedrock-runtime')
        
        # Test inference
        test_prompt = """
You are Agent A. Respond with JSON:
{
    "status": "accepted",
    "amount": 1000000,
    "offer_id": "test-123",
    "decision_reason": "Test decision",
    "timestamp": "2024-01-01T00:00:00Z"
}
"""
        
        print("   🧪 Testing Bedrock inference...")
        response = bedrock_client.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            body=json.dumps({
                "prompt": test_prompt,
                "max_tokens_to_sample": 200,
                "temperature": 0.7
            })
        )
        
        response_body = json.loads(response['body'].read())
        completion = response_body['completion']
        
        print(f"   📤 Response: {completion}")
        
        # Parse JSON
        try:
            parsed = json.loads(completion.strip())
            print(f"   ✅ JSON parsed: {parsed}")
            return True
        except json.JSONDecodeError:
            print(f"   ⚠️  Not valid JSON: {completion}")
            return False
            
    except Exception as e:
        print(f"   ❌ Bedrock test failed: {e}")
        return False

if __name__ == "__main__":
    success = test_aws_bedrock()
    if success:
        print("\n✅ AWS Bedrock setup successful!")
        print("You can now run Agent A with real Bedrock.")
    else:
        print("\n❌ AWS Bedrock setup failed.")
        print("Check your credentials and region.")
